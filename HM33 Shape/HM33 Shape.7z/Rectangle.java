public class Rectangle extends Shape {

    int x1;
    int x2;
    int x3;
    int y1;
    int y2;
    int y3;

    public Rectangle(String color, int x1, int x2, int x3, int y1, int y2, int y3) {

        super(color);
        this.x1 = x1;
        this.x2 = x2;
        this.x3 = x3;
        this.y1 = y1;
        this.y2 = y2;
        this.y3 = y3;
    }

    public void draw() {

        System.out.println("нарисован " + color + " прямоугольник с координатами: " + x1 + ":" + y1 + " " + x2 + ":" + y2 + " " + x3 + ":" + y3);
    }

    public boolean equals(Rectangle shape) {

        return ((shape.color == color) && (shape.x1 == x1) && (shape.x2 == x2) && (shape.x3 == x3) && (shape.y1 == y1) && (shape.y2 == y2) && (shape.y3 == y3));
    }
}