public class Circle extends Shape {

    int x1;
    int y1;
    int x2;
    int y2;
    int R;

    public Circle(String color, int x1, int y1, int x2, int y2, int R) {

        super(color);
        this.x1 = x1;
        this.x2 = x2;
        this.y1 = y1;
        this.y2 = y2;
        this.R = R;
    }

    public void draw() {
        System.out.println("нарисован " + color + " круг c координатами: " + x1 + ":" + y1 + " " + x2 + ":" + y2 + " Радиус: " + R);
    }

    public boolean equals(Circle shape) {

        return ((shape.color == color) && (shape.x1 == x1) && (shape.x2 == x2) && (shape.y1 == y1) && (shape.y2 == y2) && (shape.R == R));
    }
}