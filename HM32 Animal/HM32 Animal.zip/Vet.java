public class Vet {

    public void treatAnimal(Animal animal) {

        System.out.println(animal.getName());
        System.out.println(animal.getFood());
        System.out.println(animal.getLocation());
    }
}