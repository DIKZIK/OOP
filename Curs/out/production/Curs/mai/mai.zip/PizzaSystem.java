package mai;

import mai.user.*;
import mai.Map.*;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.Deque;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.Scanner;

public class PizzaSystem {

    private static final String REG_CHOOSE = "reg";
    private static final String ENTER_CHOOSE = "ent";
    private static final String HELP_CHOOSE = "help";
    private static final String END_CHOOSE = "end";
    private static final String YES_CHOOSE = "yes";
    private static final String NO_CHOOSE = "no";
    private static final String MAIN_MENU = "Выберите команду: \n[reg] - регистрация нового пользователя\n[ent] - вход в личный кабинет\n[help] - все возможные команды\n[end] - завершение работы";
    private static final String ENTER_LOGIN = "введите логин: ";
    private static final String ENTER_PASSWORD = "введите пароль: ";
    private static final int NUMBER_OF_ARGS = 2;
    static HashMap<String, Client> users = new HashMap<>();
    static Scanner input = new Scanner(System.in);
    static City city = new City();

    public static void main(String[] args) {

        Deque<String> FileCommand = new LinkedList<>();
        if (args.length == NUMBER_OF_ARGS && (args[0].equalsIgnoreCase("-f") || args[0].equalsIgnoreCase("--file"))) {
            System.out.println("Взять последовательность команд из файла? [yes]/[no]");
            String choose = input.nextLine();
            if (choose.equalsIgnoreCase(YES_CHOOSE)) {
                try (BufferedReader bufReader = new BufferedReader(new FileReader(args[1]))) {
                    String s;
                    while ((s = bufReader.readLine()) != null) {
                        FileCommand.add(s);
                    }
                } catch (IOException e) {
                    System.out.println("Файл не найден. Повторите попытку");
                }
            } else if(choose.equals(NO_CHOOSE)){
                System.out.println("Действие отменено! Переходим к меню выбора действий!");
                mainMenu();
            } else {
                System.out.println("Команда не распознана");
            }
        } else {
            mainMenu();
        }
    }


    private static void mainMenu() {
        String choose = "";
        System.out.println("Добро пожаловать в нашу пиццерию!");
        while (!choose.equals("end")) {
            System.out.println(MAIN_MENU);
            choose = input.nextLine().toLowerCase();
            switch (choose) {
                case REG_CHOOSE:
                    System.out.println("Введите имя: ");
                    String nickname = input.nextLine();
                    System.out.println(ENTER_LOGIN);
                    String login = input.nextLine();
                    System.out.println(ENTER_PASSWORD);
                    String password = input.nextLine();
                    System.out.println("Выберите номер вашего района: ");
                    StringBuilder bufferDistricts = new StringBuilder();
                    for (int i = 0; i < City.nameDistricts.size(); i++) {
                        bufferDistricts.append(i + 1).append(") ").append(City.nameDistricts.get(i)).append("\n");
                    }
                    System.out.print(bufferDistricts.toString());
                    Integer district = input.nextInt();
                    input.nextLine();
                    users.put(login, new Client(nickname, login, password, district - 1));
                    break;
                case ENTER_CHOOSE:
                    System.out.println(ENTER_LOGIN);
                    String takeLogin = input.nextLine();
                    if (users.containsKey(takeLogin)) {
                        System.out.println(ENTER_PASSWORD);
                        String takePassword = input.nextLine();
                        if (users.get(takeLogin).enter(takeLogin, takePassword)) {
                            System.out.println("Вход выполнен!");
                            System.out.println("Хотите заказать пиццу?");
                            String takeCommand = input.nextLine().toLowerCase();
                            if (takeCommand.equals(YES_CHOOSE)) {
                                city.makeRoad(users.get(takeLogin).getDist());
                            } else {
                                System.out.println("Заказ пиццы отменён, попробуйте снова");
                            }
                        } else {
                            System.out.println("Неверный пароль");
                        }
                    } else {
                        System.out.println("Такого логина нет в базе");
                    }
                case END_CHOOSE:
                    System.out.println("Сохранить список введенных команд? [yes]/[no]");
                    String save = input.nextLine().toLowerCase();;
                    if(save.equals("yes")){
                    }
            }
        }
    }
}