package mai.user;

public class Admin extends User {

    public Admin(String name, String login, String password) {

        super("ADMIN", "admin", "admin");
    }
}
